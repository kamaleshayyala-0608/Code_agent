import os
import zipfile

def create_zip():
    workspace_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    parent_dir = os.path.dirname(workspace_dir)
    folder_name = os.path.basename(workspace_dir)
    
    zip_path = os.path.join(workspace_dir, "code_agent_clean.zip")
    
    exclude_dirs = {
        os.path.normpath(os.path.join(workspace_dir, "venv")),
        os.path.normpath(os.path.join(workspace_dir, "node_modules")),
        os.path.normpath(os.path.join(workspace_dir, ".git")),
    }
    
    print(f"Workspace directory: {workspace_dir}")
    print(f"Parent directory: {parent_dir}")
    print(f"Target Zip path: {zip_path}")
    print(f"Excluding directories: {[os.path.basename(d) for d in exclude_dirs]}")
    
    count = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(workspace_dir):
            norm_root = os.path.normpath(root)
            
            # Skip excluded directories and their contents
            should_skip = False
            for ex in exclude_dirs:
                if norm_root == ex or norm_root.startswith(ex + os.sep):
                    should_skip = True
                    break
            
            if should_skip:
                continue
                
            for file in files:
                filepath = os.path.join(root, file)
                norm_filepath = os.path.normpath(filepath)
                
                # Skip the output zip file itself
                if norm_filepath == os.path.normpath(zip_path):
                    continue
                    
                # Relative path from parent directory so it starts with "code_agent"
                arcname = os.path.relpath(filepath, parent_dir)
                zipf.write(filepath, arcname)
                count += 1
                
    print(f"Successfully zipped {count} files into {zip_path}")

if __name__ == "__main__":
    create_zip()
